
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'cmac5000',
  applicationName: 'apollo-lambda',
  appUid: 'tm779xT5b5ByybJj14',
  orgUid: '26dfeea1-6159-4669-8b1f-9db97b8a8b65',
  deploymentUid: 'd50373c6-803b-49fd-8cda-f6fd0e29afca',
  serviceName: 'apollo-lambda',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'apollo-lambda-dev-getBookmarkInfo', timeout: 6 };

try {
  const userHandler = require('./getBookmarkInfo.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getBookmarkInfoHandler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}