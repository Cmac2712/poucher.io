import { useState } from "react"
import { UpdateBookmark } from "../UpdateBookmark"

import { Bookmark } from "./Bookmarks"

export const BookmarkPreview = ({
    id,
    url,
    title,
    description
}: Bookmark) => {

    const [updateMode, setUpdateMode] = useState(false)

    if (updateMode) return ( 
        <UpdateBookmark
            id={id}
            title={title}
            description={description}
            setMode={setUpdateMode}
        /> 
    )

    return (
     <>
        <a
            href={url}
            target="_blank"
        >
            <h2 className="text-xl">{title}</h2>
            <p>{description}</p>
        </a>

        <button
            className="text-green-900 font-bold uppercase"
            onClick={() => {
                setUpdateMode(true)
            }
            }
        >Update</button>
    </>
    )

}