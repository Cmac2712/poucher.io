import { useState } from "react"
import { useQuery, useMutation, gql } from "@apollo/client"
import { BookmarkPreview } from "./BookmarkPreview"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faAngleRight } from '@fortawesome/free-solid-svg-icons'
import { faAngleLeft } from '@fortawesome/free-solid-svg-icons'

export interface Bookmark {
    id: number
    title: string
    description: string
    url: string
    videoURL?: string
    screenshotURL?: string
    createdAt: string
}

const GET_BOOKMARKS_BY_AUTHOR = gql`
  query GetBookmarksByAuthor(
      $id: ID!
      $offset: Int
      $limit: Int
    ) {
    getBookmarksByAuthor(
        id: $id
        offset: $offset
        limit: $limit
      ) {
      id
      title
      description
      url
      videoURL
      screenshotURL
      createdAt
    }
  }
`

interface Props {
  authorID: string
}

export const Bookmarks = ({ 
  authorID 
}:Props) => {

    const [perPage, setPerPage] = useState(5)
    const [offset, setOffset] = useState(0)

    const { loading, error, data, fetchMore } = useQuery<{
        getBookmarksByAuthor: Bookmark[]
    }>(GET_BOOKMARKS_BY_AUTHOR, {
        variables: {
          id: authorID,
          offset,
          limit: perPage
        }
    })

    if (loading) return (
      <div className="mb-4">
        <p>Loading...</p>
      </div>
    )

    if (error) return <p>Error :(</p>;

    return (
      <div>
        <ul className="mb-4 px-3 py-6 flex flex-wrap">
            {data?.getBookmarksByAuthor?.map(({ id, screenshotURL, url, title, description }) => {

               return (
                  <li 
                    className="pb-2 mb-3 basis-full flex items-start"
                    key={id}
                  >

                    <img 
                      className="mt-1 mr-4 rounded"
                      width={100}
                      src={`https://d16sq6175am0h2.cloudfront.net/${screenshotURL}`} 
                      alt="" 
                    />

                    <BookmarkPreview
                      id={id}
                      url={url}
                      title={title}
                      description={description}
                    />

                  </li>
              )
            }

            )}
            <li>

<div className="btn-group">
  <button 
    onClick={() => {
      fetchMore({
        variables: {
          id: authorID,
          offset: offset - perPage,
          limit: perPage
        }
      })
      setOffset(offset - perPage)
    }}
    className="btn btn-md"
  >
    <FontAwesomeIcon icon={faAngleLeft} />
  </button>
  <button className="btn btn-md">1</button>
  <button className="btn btn-md btn-active">2</button>
  <button className="btn btn-md">3</button>
  <button className="btn btn-md">4</button>
  <button
    onClick={() => {
      fetchMore({
        variables: {
          id: authorID,
          offset: offset + perPage,
          limit: perPage
        }
      })
      setOffset(offset + perPage)
    }}
    className="btn btn-md"
  >
    <FontAwesomeIcon icon={faAngleRight} />
  </button>
</div>
              <button
                onClick={() => {

                  fetchMore({
                    variables: {
                      id: authorID,
                      offset: offset - perPage,
                      limit: perPage
                    }
                  })

                  setOffset(offset - perPage)

                }}
              >
                Prev page
              </button>

              <button
                onClick={() => {

                  fetchMore({
                    variables: {
                      id: authorID,
                      offset: offset + perPage,
                      limit: perPage
                    }
                  })

                  setOffset(offset + perPage)

                }}
              >
                Next page
              </button>
            </li>
        </ul>

      </div>
    );
}

export { GET_BOOKMARKS_BY_AUTHOR }