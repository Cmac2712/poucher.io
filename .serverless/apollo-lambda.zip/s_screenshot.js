
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'cmac5000',
  applicationName: 'apollo-lambda',
  appUid: 'tm779xT5b5ByybJj14',
  orgUid: '26dfeea1-6159-4669-8b1f-9db97b8a8b65',
  deploymentUid: 'a093e8bf-b1f2-48bf-bc20-a3042f72153c',
  serviceName: 'apollo-lambda',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'apollo-lambda-dev-screenshot', timeout: 6 };

try {
  const userHandler = require('./screenshot.js');
  module.exports.handler = serverlessSDK.handler(userHandler.screenshotHandler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}