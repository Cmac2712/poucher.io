
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'cmac5000',
  applicationName: 'apollo-lambda',
  appUid: 'tm779xT5b5ByybJj14',
  orgUid: '26dfeea1-6159-4669-8b1f-9db97b8a8b65',
  deploymentUid: '8ea62167-9297-4273-97b8-efb1dc1171f0',
  serviceName: 'apollo-lambda',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'apollo-lambda-dev-video', timeout: 6 };

try {
  const userHandler = require('./video.js');
  module.exports.handler = serverlessSDK.handler(userHandler.videoHandler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}